from compressor.conf import CompressorConf  # noqa
